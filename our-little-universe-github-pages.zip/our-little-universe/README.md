# Our Little Universe — F1-inspired romantic website

A responsive static website made with HTML, CSS, and vanilla JavaScript. It can be hosted for free on GitHub Pages.

## Files
- `index.html` — page structure
- `style.css` — layout, colors, responsive design, and animations
- `script.js` — names, anniversary counter, music control, letter, checklist
- `assets/photos/` — add your photos here
- `assets/music/` — add your song here

## Personalize it
1. Open `script.js`.
2. Change `partnerOne`, `partnerTwo`, `startDate`, and `letter` in `CONFIG`.
3. Add photos using these exact filenames:
   - `assets/photos/driver-one.jpg`
   - `assets/photos/driver-two.jpg`
   - `assets/photos/memory-one.jpg`
   - `assets/photos/memory-two.jpg`
   - `assets/photos/memory-three.jpg`
4. Add your own audio file as `assets/music/our-song.mp3`.
5. If your files use another format or filename, update the `src` in `index.html`.

Use photos and music you own or have permission to share. Avoid uploading private material to a public repository.

## Test locally
Open `index.html` in your browser. For the most reliable local testing, use VS Code with the Live Server extension.

## Publish on GitHub Pages
1. Create a **public** GitHub repository named `our-little-universe`.
2. Upload the files and folders in this project. Make sure `index.html` is in the repository root.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select branch `main` and folder `/(root)`, then click **Save**.
6. Wait for the deployment to finish. Your site URL will usually be:
   `https://YOUR-USERNAME.github.io/our-little-universe/`

## Important limitations
- GitHub Pages serves static files. The letter is part of `script.js`, so edits must be made in the code and redeployed.
- The bucket-list checkmarks are saved only in the current browser using local storage. They are not shared between you and your partner.
- Music playback starts only after a visitor taps the sound button.
- A shared online letter editor, shared checklist, login, or private storage requires a backend such as Firebase or Supabase.
- A public repository makes its source code and uploaded files visible. Do not store passwords, secrets, or private photos you do not want exposed.
